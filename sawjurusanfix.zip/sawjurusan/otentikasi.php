<?php
include 'inc/koneksi.php';

function antiinjection($data)
{
    global $conn;
    $filter_sql = $conn->real_escape_string(stripslashes(strip_tags(htmlspecialchars($data, ENT_QUOTES))));
    return $filter_sql;
}

session_start();

// Tangkap data dari form login
$username = $_POST['username'];
$password = md5($_POST['password']);

// Untuk mencegah SQL injection
$username = antiinjection($username);
$password = antiinjection($password);

$loginadmin = $conn->query("SELECT * FROM admin WHERE username='$username' AND password='$password'");
$q = $loginadmin->fetch_array();

if ($loginadmin->num_rows == 1) {
    // Jika user dan password sudah terdaftar di database
    // Buat session dengan username, password, dan nama user yang login
    $_SESSION['username'] = $q['username'];
    $_SESSION['password'] = $q['password'];
    $_SESSION['nama'] = $q['nama'];

    // Redirect ke halaman index admin
    header('location: admin/index.php');
} else {
    // Jika username atau password tidak terdaftar di database
    header('location: index.php?error=4');
}
?>
