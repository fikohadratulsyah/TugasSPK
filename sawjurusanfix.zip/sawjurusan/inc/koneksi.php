<?php
$server = "localhost";
$username = "root";
$password = "";
$database = "sawjurusan";
$conn = new mysqli($server, $username, $password, $database);
if ($conn->connect_error) {
    die("Gagal konek ke server MySQL: " . $conn->connect_error);
}
?>