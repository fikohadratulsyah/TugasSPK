<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.5.1/chosen.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.5.1/chosen.jquery.min.js"></script>
<div id="content">
    <!-- Page title -->
    <div class="page-title">
        <h5><i class="fa fa-tag"></i> Halaman Tambah Klasifikasi</h5>
    </div>
    <form class="form-horizontal" action="?spk=Klasifikasi_Tambah" method="post" role="form">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6 class="panel-title">Tambah Klasifikasi</h6>
            </div>
            <div class="panel-body">
                <div class="col-sm-6">
                    <div class="form-group">
                        <label class="col-sm-5 control-label" style="text-align:right;">Nama Calon Siswa</label>
                        <div class="col-sm-7">
                            <select name='id_siswa' data-placeholder="Pilih Calon Siswa..." class="chosen select" style="width:200px;">
                                <option></option>
                                <?php
                                $query = "SELECT * FROM calonsiswa ORDER BY nama_siswa ASC";
                                $hasil = mysqli_query($connection, $query);
                                while ($data = mysqli_fetch_array($hasil)) {
                                    echo "<option value='" . $data['id_siswa'] . "'>" . $data['nama_siswa'] . " - " . $data['nama_asal_sekolah'] . "</option>";
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    <!-- ... Form fields for other criteria ... -->
                </div>
                <!-- ... Additional column for form fields ... -->
            </div>
        </div>
    </form>
</div>
<script type="text/javascript">
    $(document).ready(function() {
        $(".chosen").chosen();
    });
</script>
<?php
if (isset($_POST['simpan'])) {
    $id_siswa = $_POST['id_siswa'];
    // ... Retrieve values for other criteria ...
    $sql = "INSERT INTO klasifikasi (id_siswa, nilai_matematika, nilai_bahasaindonesia, nilai_bahasainggris, nilai_ipa, nilai_tik, minat_tkj, minat_tav, minat_tab, minat_titl) VALUES ('$id_siswa', '$nilai_matematika', '$nilai_bahasaindonesia', '$nilai_bahasainggris', '$nilai_ipa', '$nilai_tik', '$minat_tkj', '$minat_tav', '$minat_tab', '$minat_titl')";
    $query = mysqli_query($conn, $sql);
    if ($query) {
        echo "<script>window.alert('Klasifikasi berhasil ditambah'); window.location.href='?spk=Klasifikasi';</script>";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($connection);
    }
}
?>
