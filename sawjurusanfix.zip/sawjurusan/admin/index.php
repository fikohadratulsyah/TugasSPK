<body>
	<div class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container-fluid">
            <div class="navbar-header">               
				<h4 style="color:white;">SPK Penentuan Jurusan Metode SAW</h4>
            </div>
            <div class="navbar-right">               
            <a class="navbar-brand" href="logout.php"><i class="fa fa-sign-out"></i> Sign out</a>
            </div>            
        </div>
    </div>

	<div id="page" align="center">
<?php  
include "head.php";
?>
		<?php include "content.php" ?>
		<?php include "footer.php" ?>
	</div>
        
</body>
</html>
