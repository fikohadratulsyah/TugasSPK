<!-- Footer -->
		<div class="footer">
		<b>&copy; Copyright <?php echo date("Y") ?>. | SPK Penentuan Jurusan Metode SAW</b>
		</div>
		